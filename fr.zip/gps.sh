#!/bin/bash
sudo killall gpsd; sudo gpsd /dev/ttyUSB0 -F /var/run/gpsd.sock